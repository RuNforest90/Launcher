-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 12 2024 г., 19:13
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `praktika`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bonuses`
--

CREATE TABLE `bonuses` (
  `id` int NOT NULL,
  `bonus` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `coupons`
--

CREATE TABLE `coupons` (
  `id` int NOT NULL,
  `coupon` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE `messages` (
  `id` int NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`id`, `message`, `created_at`) VALUES
(1, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:10:24'),
(2, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:10:26'),
(3, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:10:27'),
(4, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:11:05'),
(5, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:11:08'),
(6, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:16:11'),
(7, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:16:23'),
(8, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:16:23'),
(9, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:16:24'),
(10, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:16:24'),
(11, 'Что нового?', '2024-12-08 09:16:27'),
(12, 'Что нового?', '2024-12-08 09:16:31'),
(13, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:22:46'),
(14, 'Здраствуйте, проблема с интернетом', '2024-12-08 09:22:47'),
(15, 'Здраствуйте, проблема с интернетом', '2024-12-08 16:35:40'),
(16, 'Что нового?', '2024-12-10 10:57:38'),
(17, 'апппп', '2024-12-10 10:57:41');

-- --------------------------------------------------------

--
-- Структура таблицы `prizes`
--

CREATE TABLE `prizes` (
  `id` int NOT NULL,
  `prize` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `prizes`
--

INSERT INTO `prizes` (`id`, `prize`) VALUES
(1, 'Ali - ISHOPER'),
(2, 'Яндекс+ - BESTPLUS'),
(3, 'Яндекс еда - SHOP50'),
(4, 'М.Видео - Индивидуальный'),
(5, 'Burger KING - 5557753'),
(6, 'Яндекс еда - CHICK500'),
(7, 'KION - KIONMTSBANK'),
(8, 'HOFF - 200detskaya, 300gostinaya'),
(9, 'Яндекс + - WOWBOOK'),
(10, 'KION - KIONMTSBANK'),
(11, 'KION - KIONSAVE'),
(12, 'Яндекс еда - COMEDY90'),
(13, 'Wink - индивидуальный'),
(14, 'Genshin Impact - LA5E77CLZX5V'),
(15, 'Яндекс + - TNPASKSLCE'),
(16, 'Genshin Impact - WAM5UWWU28NV, LA5E77CLZX5V'),
(17, 'Яндекс Go - DELWEB50'),
(18, 'KION - ADVENTMTC'),
(19, 'Яндекс Путишествия - PROMOKODI2500'),
(20, 'Кинопоиск - FANTASY');

-- --------------------------------------------------------

--
-- Структура таблицы `scores`
--

CREATE TABLE `scores` (
  `id` int NOT NULL,
  `player_name` varchar(255) NOT NULL,
  `score` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `tariff` varchar(50) NOT NULL,
  `bonuses` int NOT NULL,
  `prizes_user` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`login`, `password`, `tariff`, `bonuses`, `prizes_user`) VALUES
('arseniy', 'a', 'Телевидение', 0, 0),
('arseniy', 'a', 'Телевидение', 0, 0),
('arseniy', 'a', 'Телевидение', 0, 0),
('а', '123', 'Интернет домашний', 0, 0),
('A', '123', 'Телевидение', 0, 0),
('A', '123', 'Телевидение', 0, 0),
('A', '123', 'Телевидение', 0, 0),
('A', '123', 'Телевидение', 0, 0),
('A', '123', 'Телевидение', 0, 0),
('A', '123', 'Телевидение', 0, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bonuses`
--
ALTER TABLE `bonuses`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bonuses`
--
ALTER TABLE `bonuses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `scores`
--
ALTER TABLE `scores`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
