


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style_index.css">
</head>
<body>
    <div class="center">
        <div class="logo">
            <img src="img/Logo.png" alt="" class="img_logo">
        </div>
        <div class="menu">
            <a style="cursor:pointer" onclick="OpenGame()" class="text_href">Игра</a>
            <a style="cursor:pointer" href="./index.php" class="text_href">Подержка</a>
            <a style="cursor:pointer" href="https://ertelecom.ru" class="text_href">Официальный сайт</a>
            <a style="cursor:pointer" href="./registr.php" class="text_href">Аккаунт</a>
        </div>

    </div>
    <div class="osnova">
        <?php
            session_start();

            // Включаем скрипт для получения купонов
            include 'getCoupons.php';
        ?>

        <div class="osnova_contacts">
            <h1>Купоны</h1>
            <div id="Prizes">
                <?php
                    if (isset($_SESSION['coupons'])) {
                        //foreach ($_SESSION['coupons'] as $coupon) {
                            echo "Вы получили купон: " . htmlentities($randomCoupon['prize']); // предположим, что у вас есть поле 'name'
                        //}
                    } else {
                    echo "<div>Нет доступных купонов.</div>";
                    }
                ?>
            </div>
        </div>
        <div class="osnova_chat" id="messages">

            


            <div class="chat">
                <form id="chatForm">
                    <select id="messageSelect">
                        <option value="Здраствуйте, проблема с интернетом">Здраствуйте, проблема с интернетом</option>
                        <option value="Как дела?">Как дела?</option>
                        <option value="Что нового?">Что нового?</option>
                    </select>
                    <input type="text" id="customMessage" placeholder="Введите свое сообщение" />
                    <button type="button" onclick="sendMessage()">Отправить</button>
                </form>
    
                
            </div>
        </div>
    </div>


</body>
</html>
<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$dbh = mysqli_connect('localhost', 'root', '', 'praktika');
?>
<script>
    function OpenGame() {
        var x = screen.width/2 - 1050/2;
        var y = screen.height/2 - 700/2;
        window.open('dino.html', 'Игра', 'width=1200,height=800,left='+x+',top='+y);
    }

    function sendMessage() {
        const messageSelect = document.getElementById('messageSelect');
        const customMessage = document.getElementById('customMessage').value;
        const message = customMessage.trim() !== '' ? customMessage : messageSelect.value;

        fetch('send_message.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'message=' + encodeURIComponent(message)
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById('messages').innerHTML += '<p>' + message + '</p>';
            // Очистка текстового поля после отправки сообщения
            document.getElementById('customMessage').value = '';
        })
        .catch(error => console.error('Ошибка:', error));
    }

document.addEventListener("DOMContentLoaded", function() {
    fetch('get_messages.php')
        .then(response => response.json())
        .then(messages => {
            messages.forEach(msg => {
                document.getElementById('messages').innerHTML += '<p>' + msg.message + ' (' + msg.created_at + ')</p>';
            });
        })
        .catch(error => console.error('Ошибка:', error));
});
</script>