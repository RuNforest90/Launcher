<?php
// Подключение к базе данных
$host = 'localhost'; // Хост
$db = 'praktika'; // Имя базы данных
$user = 'root'; // Имя пользователя
$pass = ''; // Пароль

$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    // Получаем купоны из БД
    $stmt = $pdo->query("SELECT * FROM prizes");
    $coupons = $stmt->fetchAll();

    // Сохраняем купоны в сессию или в файл для дальнейшего использования
    session_start();
    $_SESSION['coupons'] = $coupons;

    // Проверяем, есть ли купоны
    if (!empty($coupons)) {
        // Выбираем случайный индекс
        $randomIndex = array_rand($coupons);
        // Получаем случайный купон
        $randomCoupon = $coupons[$randomIndex];

        // Отображаем информацию о купоне
        //echo "Вы получили купон: " . htmlentities($randomCoupon['prize']); // предположим, что у вас есть поле 'name'
    } else {
        echo "Нет доступных купонов.";
    }

} catch (PDOException $e) {
    echo "Ошибка подключения: " . $e->getMessage();
}
?>
