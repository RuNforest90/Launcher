<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Подключение к базе данных
    $servername = "localhost";
    $username = "root"; // ваш пользователь
    $password = ""; // ваш пароль
    $dbname = "praktika";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Проверка соединения
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Получение данных из формы
    $login = $_POST['loginAuth'];
    $password = /*password_hash(*/$_POST['passwordAuth']/*, PASSWORD_DEFAULT)*/; // Хэширование пароля

    $result = mysqli_query($conn, "SELECT login, password FROM user WHERE login = '$login' AND password = '$password'"); 
    $count = mysqli_num_rows($result); 

    if ($count > 0) { 
        echo "Авторизация прошла успешно!";
        ?>
        <script>
            sessionStorage.setItem('username', '<?php echo $login; ?>');
            window.location.href = "index.php";
        </script>
        <?
        exit(); // Не забудьте добавить exit, чтобы остановить выполнение скрипта
    } else { 
        echo "Такого пользователя нет";
        header("Location: registr.php");
        exit();
    }

    $conn->close();
}



?>