<?php
// Подключение к БД
    $servername = "localhost";
    $username = "root"; // ваш пользователь
    $password = ""; // ваш пароль
    $dbname = "praktika";

    $conn = new mysqli($servername, $username, $password, $dbname);

// Получаем данные из POST-запроса
$player_name = $_POST['player_name'];
$score = $_POST['score'];

// Сохранение счета в базу данных
$stmt = $pdo->prepare("INSERT INTO scores (player_name, score) VALUES (?, ?)");
$stmt->execute([$player_name, $score]);

// Логика для получения бонуса или купона
$bonus = '';
if ($score >= 100) {
    // Пример: если счет выше 100, выбираем случайный купон из базы данных
    $stmt = $pdo->query("SELECT coupon FROM coupons ORDER BY RAND() LIMIT 1");
    $bonus = $stmt->fetchColumn();
} elseif ($score >= 50) {
    // Пример: если счет от 50 до 99, выбираем случайный бонус
    $stmt = $pdo->query("SELECT bonus FROM bonuses ORDER BY RAND() LIMIT 1");
    $bonus = $stmt->fetchColumn();
}

// Возвращаем ответ с бонусом
echo json_encode(['bonus' => $bonus]);
?>

CREATE TABLE scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    player_name VARCHAR(255) NOT NULL,
    score INT NOT NULL
);

CREATE TABLE coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    coupon VARCHAR(255) NOT NULL
);

CREATE TABLE bonuses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bonus VARCHAR(255) NOT NULL
);
