<?php
$servername = "localhost"; // или ваш сервер
$username = "root"; // ваше имя пользователя
$password = ""; // ваш пароль
$dbname = "praktika";

// Создаем соединение
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверяем соединение
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получаем данные о призах
$sql = "SELECT prize FROM prizes";
$result = $conn->query($sql);

// Создаем массив для хранения призов
$prizes = [];

if ($result->num_rows > 0) {
    // Выводим данные каждого ряда
    while($row = $result->fetch_assoc()) {
        $prizes[] = $row['prize'];
    }
} else {
    echo "0 results";
}

$conn->close();

// Выводим призы в формате JSON
echo json_encode($prizes);
?>
