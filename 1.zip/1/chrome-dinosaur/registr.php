<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Подключение к базе данных
    $servername = "localhost";
    $username = "root"; // ваш пользователь
    $password = ""; // ваш пароль
    $dbname = "praktika";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Проверка соединения
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $login = $_POST['login'];
    $password = /*password_hash(*/$_POST['password']/*, PASSWORD_DEFAULT)*/; // Хэширование пароля

    $result = mysqli_query($conn, "SELECT * FROM user WHERE login='$login' OR password='$password'"); 
    $count = mysqli_num_rows($result); 

    if ($count > 0) { 

        echo "Такой пользователь уже существует"; 
        header("Location: registr.php");
        exit();
      } else { 
        
        $tariff = $_POST['tariff'];
        $bonuses = 0;
        $prizes_user = 0;
    
        // Подготовка и выполнение запроса
        $stmt = $conn->prepare("INSERT INTO user VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssii", $login, $password, $tariff, $bonuses, $prizes_user);
    
        if ($stmt->execute()) {
            echo "Регистрация прошла успешно!";
            ?>
            <script>
                sessionStorage.setItem('username', '<?php echo $login; ?>');
                window.location.href = "index.php";
            </script>
            <?
            exit(); // Не забудьте добавить exit, чтобы остановить выполнение скрипта
        } else {
            echo "Ошибка: " . $stmt->error;
        }
    
        $stmt->close();
        $conn->close();
      }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <style>
        body, html { width: 100%; height: 100%; }
    </style>
</head>
<body>
<div style="width: 100%; height: 100%; display: flex; align-items: center; flex-direction: row; justify-content: space-evenly;">
    <div style="width:250px; height: 300px; border-radius: 20px; background-color: #50a8fa; display: flex; flex-direction: column; align-items: center;">
    <h2>Регистрация</h2>
    <form method="POST" action="" style="display: flex; flex-direction: column;">
        <label for="login">Логин:</label>
        <input type="text" id="login" name="login" required><br>

        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required><br>

        <label for="tariff">Тариф:</label>
        <select id="tariff" name="tariff" required>
            <option value="Телевидение">Телевидение</option>
            <option value="Интернет домашний">Интернет домашний</option>
            <option value="Общий">Общий</option>
        </select><br>

        <input type="submit" value="Зарегистрироваться">
    </form>
    </div>
    <div style="width:250px; height: 300px; border-radius: 20px; background-color: #50a8fa; display: flex; flex-direction: column; align-items: center;">
    <h2>Авторизация</h2>
    <form method="POST" action="Auth.php" style="display: flex; flex-direction: column;">
        <label for="login">Логин:</label>
        <input type="text" id="loginAuth" name="loginAuth" required><br>

        <label for="password">Пароль:</label>
        <input type="password" id="passwordAuth" name="passwordAuth" required><br>

        <input type="submit" value="Авторизоваться">
    </form>
    </div>
    </div>
</body>
</html>